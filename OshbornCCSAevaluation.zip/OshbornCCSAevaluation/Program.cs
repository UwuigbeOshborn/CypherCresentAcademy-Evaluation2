﻿// See https://aka.ms/new-console-template for more information
using OshbornCCSAevaluation;


//FluentNHibernateHelper.OpenSession();

Console.WriteLine("Welcome to Oshborn's Hospital Management System!\n");


var royalHealthCare = new Hospital() { Address = "N0. 20 PTI road warri, Delta state."};

var receptionistCollins = new Receptionist() { Name = "Collins", Hospital = royalHealthCare, Address = "No. 13 Tunde street, Edo state" };

var doctorMurphy = new Doctor() { Name = "Murphy", Hospital = royalHealthCare, Address = "No. 11 miki street, Delta state"};
var doctorIfe = new Doctor() { Name = "Murphy", Hospital = royalHealthCare, Address = "No. 12 Rumuola street, PH" };
var doctorMark = new Doctor() { Name = "Murphy", Hospital = royalHealthCare, Address = "No. 13 chioba street, PH" };
var doctorLucky = new Doctor() { Name = "Murphy", Hospital = royalHealthCare, Address = "No. 14 Rumuola street, PH" };
var doctorVivian = new Doctor() { Name = "Murphy", Hospital = royalHealthCare, Address = "No. 15 osas street, Edo state" };

var patient1 = new RegisteredPatient(royalHealthCare) { Name = "John", Address = "No. 1 Tran Amadi", Doctor = doctorMurphy, Receptionist = receptionistCollins };
var patient2 = new RegisteredPatient(royalHealthCare) { Name = "Kate", Address = "No. 2 Ola street", Doctor = doctorMurphy, Receptionist = receptionistCollins };
var patient3 = new RegisteredPatient(royalHealthCare) { Name = "Sarah", Address = "No. 3 freeland street", Doctor = doctorIfe, Receptionist = receptionistCollins };
var patient4 = new RegisteredPatient(royalHealthCare) { Name = "Emma", Address = "No. 4 Tran street", Doctor = doctorIfe, Receptionist = receptionistCollins };
var patient5 = new RegisteredPatient(royalHealthCare) { Name = "Kelvin", Address = "No. 5 kaka street", Doctor = doctorMark, Receptionist = receptionistCollins };
var patient6 = new UnregisteredPatient(royalHealthCare) { Name = "James", Address = "No. 6 peace close", Doctor = doctorMark, Receptionist = receptionistCollins };
var patient7 = new UnregisteredPatient(royalHealthCare) { Name = "Irin", Address = "No. 7 Tran Layout", Doctor = doctorLucky, Receptionist = receptionistCollins };
var patient8 = new UnregisteredPatient(royalHealthCare) { Name = "Jax", Address = "No. 8 winner Layout", Doctor = doctorLucky, Receptionist = receptionistCollins };
var patient9 = new UnregisteredPatient(royalHealthCare) { Name = "MArk", Address = "No. 9 lawa close", Doctor = doctorVivian, Receptionist = receptionistCollins };
var patient10 = new UnregisteredPatient(royalHealthCare) { Name = "Alex", Address = "No. 10 Tran close", Doctor = doctorVivian, Receptionist = receptionistCollins };



var myPatientList = new List<Patient> { };
myPatientList.Add(patient1);
myPatientList.Add(patient2);
myPatientList.Add(patient3);
myPatientList.Add(patient4);
myPatientList.Add(patient5);
myPatientList.Add(patient6);
myPatientList.Add(patient7);
myPatientList.Add(patient8);
myPatientList.Add(patient9);
myPatientList.Add(patient10);

foreach (var item in myPatientList)
{
    item.BookAppointment(item);
    item.Register(item);
    item.SeeTheDoctor(item, royalHealthCare);
    Console.WriteLine("\n");
}