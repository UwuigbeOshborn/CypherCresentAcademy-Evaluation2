﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation.Mappings
{
    public class HospitalMap : ClassMap<Hospital>
    {
        public HospitalMap()
        {
            Id(x => x.Id);
            Map(x => x.Name);
            Map(x => x.Address);
            HasMany(x => x.Receptionist);
            //HasMany(x => x.Patients);
            HasMany(x => x.RegisteredPatient);
            HasMany(x => x.UnregisteredPatient);
            HasMany(x => x.Doctor);
        }
    }
}
