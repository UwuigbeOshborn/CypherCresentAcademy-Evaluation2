﻿//using FluentNHibernate.Mapping;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace OshbornCCSAevaluation.Mappings
//{
//    public class PatientMap : ClassMap<Patient>
//    {
//        public PatientMap()
//        {
//            Id(x => x.Id);
//            Map(x => x.Name);
//            Map(x => x.Address);
//            References(x => x.Receptionist);
//            References(x => x.Hospital);
//            References(x => x.Doctor);
//        }
//    }
//}
