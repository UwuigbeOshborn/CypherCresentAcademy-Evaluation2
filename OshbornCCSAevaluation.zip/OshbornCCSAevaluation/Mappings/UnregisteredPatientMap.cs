﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation.Mappings
{
    public class UnregisteredPatientMap : ClassMap<UnregisteredPatient>
    {
        public UnregisteredPatientMap()
        {
            Id(x => x.Id);
            Map(x => x.Name);
            Map(x => x.Address);
            References(x => x.Receptionist);
            References(x => x.Hospital);
            References(x => x.Doctor);
        }
    }
}
