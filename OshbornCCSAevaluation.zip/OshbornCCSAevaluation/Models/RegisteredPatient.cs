﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation
{
    public class RegisteredPatient : Patient
    {
        //Constructors
        public RegisteredPatient()
        {

        }
        public RegisteredPatient(Hospital hospital) : base(hospital)
        {
            Hospital = hospital;
        }
        //Methods

        //Properties

    }
}
