﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation
{
    public class Receptionist : Human
    {
        //Constructors
        public Receptionist()
        {

        }
        public Receptionist(Patient patient)
        {
            Patient = patient;  
        }
        //Methods
        public virtual void RegisterPatient(Patient patient)
        {
            Hospital.RegisterPatient(patient);
        }

        public virtual void SeeTheDoctorApproval(Patient patient, Hospital hospital)
        {
            Patient = patient;
            Hospital = hospital;
            if (Hospital.HospitalNumbers.Contains(Patient.HospitalNumber))
            {
                if (Patient is UnregisteredPatient)
                {
                    if (Hospital.AppointmentNumbers.Contains(Patient.AppointmentNumber))
                    {
                        Console.WriteLine("You can see the doctor now\n");
                        Doctor.Appointment();
                    }
                    else
                    {
                        Console.WriteLine("You currently do not have any appointmet yet, I am about booking an appointment for you, please wait shortly\n");
                        Thread.Sleep(5000);
                        Hospital.BookAppointment(patient);
                    }
                }
                else if (Patient is RegisteredPatient)
                {
                    if (Hospital.AppointmentNumbers.Contains(Patient.AppointmentNumber))
                    {
                        Console.WriteLine("You can see the doctor now\n");
                        Doctor.Appointment();
                    }
                    else
                    {
                        Console.WriteLine("You currently do not have any appointmet yet, I am about booking an appointment for you, please wait shortly\n");
                        Thread.Sleep(5000);
                        Hospital.BookAppointment(patient);
                    }
                }
            }
            else
            {
                Console.WriteLine("Please generate your hospital number first");
            }
        }

        //Properties
        public virtual Hospital Hospital { get; set; }
        public virtual Patient Patient { get; set; }
        public virtual UnregisteredPatient UnregisteredPatient { get; set; }
        public virtual RegisteredPatient RegisteredPatient { get; set; }
    }
}