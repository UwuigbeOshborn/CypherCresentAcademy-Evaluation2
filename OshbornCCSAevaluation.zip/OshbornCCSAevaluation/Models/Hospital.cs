﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation
{
    public class Hospital
    {
        //Constructors
        public Hospital()
        {

        }


        //Methods
        private string GenerateTenUniqueDigitRegistrationNumber()
        {
            string outPut = "";
            var randomNumbers = new Random();
            for (int i = 1; i <= 10; i++)
            {
                outPut = outPut.Insert(0, Convert.ToString(randomNumbers.Next(0, 10)));
            }
            foreach (var item in RegistationNumbers)
            {
                if (item == outPut)
                {
                    GenerateTenUniqueDigitRegistrationNumber();
                }
            }
            RegistationNumbers.Add(outPut);
            return outPut;
        }

        
        private string GenerateAppointmentNumber()
        {
            string outPut = "";
            var randomNumbers = new Random();

            for (int i = 1; i <= 5; i++)
            {
                outPut = outPut.Insert(0, Convert.ToString(randomNumbers.Next(0, 10)));
            }
            foreach (var item in AppointmentNumbers)
            {
                if (item == outPut)
                {
                    GenerateAppointmentNumber();
                }
            }
            AppointmentNumbers.Add(outPut);
            return outPut;
        }
        public virtual string GenerateHospitalNumber()
        {
            string outPut = "";
            var randomNumbers = new Random();

            for (int i = 1; i <= 5; i++)
            {
                outPut = outPut.Insert(0, Convert.ToString(randomNumbers.Next(0, 10)));
            }
            foreach (var item in HospitalNumbers)
            {
                if (item == outPut)
                {
                    GenerateHospitalNumber();
                }
            }
            HospitalNumbers.Add(outPut);
            return outPut;
        }

        public virtual void RegisterPatient(Patient patient)
        {
            string registationNumber = GenerateTenUniqueDigitRegistrationNumber();
            string patientDetails = $"Name: {patient.Name}, Address: {patient.Address}, Registation Number: {registationNumber}";


            patient.RegistrationNumber = registationNumber;
            PatientRegister.Add(patientDetails);

            Console.WriteLine($"Hello {patient.Name}, you are now successfully registered, Your registration number is {registationNumber}");

            DataBaseManager.AddItem(patient);
        }

        public virtual void BookAppointment(Patient patient)
        {
            string hospitalNumber = GenerateHospitalNumber();
            string appointmentNumber = GenerateAppointmentNumber();

            patient.HospitalNumber = hospitalNumber;
            patient.AppointmentNumber = appointmentNumber;

            //AppoointmentTime = new DateTimeOffset()

            string patientDetails = $"Hospital Number: {hospitalNumber}, Appointment Number: {appointmentNumber}, Appointment Time: ___, Name: {patient.Name}, Address: {patient.Address}";

            AppointmentRegister.Add(patientDetails);

            Console.WriteLine($"Hello {patient.Name}, you are now successfully booked");
            Console.WriteLine($"Your hospital number is {hospitalNumber}, While your appointment number is {appointmentNumber}");
        }

        //Properties
        public virtual int Id { get; set; }
        public virtual string Name { get; set; }
        public virtual string Address { get; set; }
        public virtual Receptionist Receptionist { get; set; }
        public virtual List<Patient> Patients { get; set; }
        public virtual List<Doctor> Doctor { get; set; } 
        
        
        //public virtual DateTimeOffset AppoointmentTime { get; set; }


        public virtual List<string> DailyRegister { get; set; } = new List<string> { };
        public virtual List<string> AppointmentRegister { get; set; } = new List<string> { };
        public virtual List<string> PatientRegister { get; set; } = new List<string> { };
        public virtual List<string> RegistationNumbers { get; set; } = new List<string> { };
        public virtual List<string> HospitalNumbers { get; set; } = new List<string> { };
        public virtual List<string> AppointmentNumbers { get; set; } = new List<string> { };
    }
}
