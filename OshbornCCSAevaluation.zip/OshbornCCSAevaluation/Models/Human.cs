﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation
{
    public class Human
    {
        //Constructors
        public Human()
        {

        }
        public Human(string name, string address)
        {
            Name = name;
            Address = address;
        }
        //Methods

        //Properties
        public virtual int Id { get; set; }
        public virtual string Name { get; set; }
        public virtual string Address { get; set; }
    }
}
