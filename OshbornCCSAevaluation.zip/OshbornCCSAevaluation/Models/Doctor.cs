﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation
{
    public class Doctor : Human
    {
        //Constructors
        public Doctor()
        {

        }
        //Methods
        public static void Appointment()
        {
            Console.WriteLine("Reviewing medical condition");
            Console.WriteLine("Adminitration of drugs");
            Console.WriteLine("Billing Management");
        }
        //Properties
        public virtual Hospital Hospital { get; set; }
        public virtual List<Patient> Patients { get; set; }
    }
}
