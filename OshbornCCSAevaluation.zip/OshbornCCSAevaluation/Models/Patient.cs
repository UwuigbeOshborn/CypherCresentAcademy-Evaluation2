﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation
{
    public class Patient : Human
    {
        //Constructors
        public Patient()
        {

        }
        public Patient(Hospital hospital)
        {
            Hospital = hospital;
        }
        //Methods
        public Patient(string name, string address) : base(name, address)
        {
        }

        public virtual void BookAppointment(Patient patient)
        {
            Hospital.BookAppointment(patient);
        }
        public virtual void Register(Patient patient)
        {
            Hospital.RegisterPatient(patient);
        }

        public virtual void SeeTheDoctor(Patient patient, Hospital hospital)
        {
            var receptionist = new Receptionist();
            receptionist.SeeTheDoctorApproval(patient, hospital);
        }

        //Properties
        public virtual Hospital Hospital { get; set; }
        public virtual Receptionist Receptionist { get; set; }
        public virtual Doctor Doctor { get; set; }


        public virtual string HospitalNumber { get; set; }
        public virtual string AppointmentNumber { get; set; }
        public virtual string RegistrationNumber { get; set; }
    }
}
