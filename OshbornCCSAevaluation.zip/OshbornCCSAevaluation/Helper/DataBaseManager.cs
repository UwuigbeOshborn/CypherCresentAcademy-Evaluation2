﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OshbornCCSAevaluation
{
    public static class DataBaseManager
    {
        //Implementing CRUD
        public static void AddItem<T>(T item)
        {
            var session = FluentNHibernateHelper.OpenSession();
            try
            {
                using (var transaction = session.BeginTransaction())
                {
                    session.Save(item);
                    transaction.Commit();
                    Console.Write("\n----------------------New row-item successfully created--------------------\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                FluentNHibernateHelper.CloseSession();
            }
        }

        public static T ReadItem<T>(T Item)
        {
            var session = FluentNHibernateHelper.OpenSession();
            try
            {
                var item = session.Get<T>(Item);
                Console.Write("\n----------------------Item successfully read------------------\n");
                return item;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return default;
            }
            finally
            {
                FluentNHibernateHelper.CloseSession();
            }
        }

        public static void ReadItem<T>(int id, T item)
        {
            var session = FluentNHibernateHelper.OpenSession();
            try
            {
                var items = session.Get<T>(id);
                Console.Write("\n----------------------Item successfully read------------------\n");
                //return items;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                //return default;
            }
            finally
            {
                FluentNHibernateHelper.CloseSession();
            }
        }

        public static void UpdateItem<T>(T item)
        {
            var session = FluentNHibernateHelper.OpenSession();
            try
            {
                using (var transaction = session.BeginTransaction())
                {
                    session.Update(item);
                    transaction.Commit();
                    Console.Write("\n----------------Row-item successfully updated------------------\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Id does not exist");
            }
            finally
            {
                FluentNHibernateHelper.CloseSession();
            }
        }

        public static void DeleteItem<T>(T item)
        {
            var session = FluentNHibernateHelper.OpenSession();
            try
            {
                using (var transaction = session.BeginTransaction())
                {
                    session.Delete(item);
                    transaction.Commit();
                    Console.Write("\n--------------------Item successfully deleted-------------------\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                FluentNHibernateHelper.CloseSession();
            }
        }
    }
}
