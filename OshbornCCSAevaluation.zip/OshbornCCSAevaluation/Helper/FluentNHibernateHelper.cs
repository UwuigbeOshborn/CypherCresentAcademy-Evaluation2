﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using NHibernate.Tool.hbm2ddl;


namespace OshbornCCSAevaluation
{
    public class FluentNHibernateHelper
    {
        private static ISessionFactory _sessionFactory;
        private static ISessionFactory SessionFactory
        {
            get
            {
                if (_sessionFactory == null)
                {
                    InitialiseSessionFactory();
                }
                return _sessionFactory;
            }
        }

        public static void InitialiseSessionFactory()
        {
            _sessionFactory = Fluently.Configure()
                .Database(MsSqlConfiguration.MsSql2012.ConnectionString(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\ELIjah\source\repos\MyLocalDataBases\Oshborn CCSA DB4.mdf;Integrated Security=True;Connect Timeout=30")
                .ShowSql())
                .Mappings(map => map.FluentMappings.AddFromAssemblyOf<Program>())
                //.ExposeConfiguration(cfg => new SchemaExport(cfg).Create(true, true))
                .BuildSessionFactory();
        }

        public static ISession OpenSession()
        {
            return SessionFactory.OpenSession();
        }
        public static ISession CloseSession()
        {
            return null;
        }


        

        // Reset the Database
        public static void ResetSessionFactory()
        {
            string selectedOption1;
            Console.Write("Are you sure you really want to reset the database, as all data would be loss? YES or NO: ");
            selectedOption1 = Convert.ToString(Console.ReadLine());
            if (selectedOption1 == "YES")
            {
                _sessionFactory = Fluently.Configure()
                .Database(MsSqlConfiguration.MsSql2012.ConnectionString(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\ELIjah\source\repos\MyLocalDataBases\Oshborn CCSA DB4.mdf;Integrated Security=True;Connect Timeout=30")
                .ShowSql())
                .Mappings(map => map.FluentMappings.AddFromAssemblyOf<Program>())
                .ExposeConfiguration(cfg => new SchemaExport(cfg).Create(true, true))
                .BuildSessionFactory();
                Console.Write("\n-------------------Database reset completed----------------------\n");
            }
            else if (selectedOption1 == "NO")
            {
                Console.Write("\n\nOkay goodbye, we will see another time;\n");
            }
            else
            {
                Console.Write("\n\nOops! it seems you entered a wrong option again. Goodbye;\n");
            }
        }
    }
}